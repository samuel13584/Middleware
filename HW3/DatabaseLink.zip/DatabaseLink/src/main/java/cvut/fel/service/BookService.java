package cvut.fel.service;

import cvut.fel.entity.Book;

public interface BookService {

    Book findById(Long id);

}
